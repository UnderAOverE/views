"""Pull the ConfigMaps consumed by an OpenShift Deployment / StatefulSet / DeploymentConfig.

Authenticates with a FID (service account user) + password against the cluster's
OAuth server using the same flow `oc login -u USER -p PASS` uses under the hood:

    GET {authorization_endpoint}?client_id=openshift-challenging-client&response_type=token
    Authorization: Basic base64(user:password)
    X-CSRF-Token: 1
    -> 302 Location: .../oauth/token/implicit#access_token=sha256~...

The resulting bearer token is then used against the Kubernetes API.
"""

from __future__ import annotations

import argparse
import asyncio
import base64
import json
import logging
import os
import time
from dataclasses import dataclass, field
from typing import Any, Literal
from urllib.parse import parse_qs, urlparse

import httpx
from tenacity import (
    before_sleep_log,
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

logger = logging.getLogger(__name__)

WorkloadKind = Literal["auto", "deployment", "statefulset", "deploymentconfig"]

# Token is valid ~24h; refresh a little early.
_TOKEN_SKEW_SECONDS = 300


# --------------------------------------------------------------------------- #
# Errors
# --------------------------------------------------------------------------- #
class OpenShiftError(Exception):
    """Base error for this module."""


class ClusterNotConfiguredError(OpenShiftError):
    """Cluster name could not be mapped to an API URL."""


class AuthenticationError(OpenShiftError):
    """FID / username / password rejected by the OAuth server."""


class WorkloadNotFoundError(OpenShiftError):
    """Deployment / StatefulSet / DeploymentConfig does not exist."""


class ApiError(OpenShiftError):
    """Non-2xx response from the Kubernetes API."""

    def __init__(self, status_code: int, message: str):
        self.status_code = status_code
        super().__init__(f"[{status_code}] {message}")


class RetryableApiError(ApiError):
    """5xx / throttling response worth retrying."""


# --------------------------------------------------------------------------- #
# Cluster resolution
# --------------------------------------------------------------------------- #
def resolve_api_url(cluster: str) -> str:
    """Map a friendly cluster name to its API server URL.

    Resolution order:
      1. ``cluster`` is already a URL -> used as-is.
      2. ``OPENSHIFT_CLUSTERS`` env var, a JSON object {"name": "https://api...:6443"}.
      3. ``OPENSHIFT_API_URL_TEMPLATE`` env var, e.g. "https://api.{cluster}.corp.net:6443".

    Args:
        cluster: Cluster name or full API URL.

    Returns:
        API server base URL without a trailing slash.

    Raises:
        ClusterNotConfiguredError: If the name cannot be resolved.
    """
    if cluster.startswith(("http://", "https://")):
        return cluster.rstrip("/")

    raw_map = os.getenv("OPENSHIFT_CLUSTERS", "").strip()
    if raw_map:
        try:
            mapping: dict[str, str] = json.loads(raw_map)
        except json.JSONDecodeError as exc:
            raise ClusterNotConfiguredError(f"OPENSHIFT_CLUSTERS is not valid JSON: {exc}") from exc
        if url := mapping.get(cluster):
            return url.rstrip("/")

    if template := os.getenv("OPENSHIFT_API_URL_TEMPLATE", "").strip():
        return template.format(cluster=cluster).rstrip("/")

    raise ClusterNotConfiguredError(
        f"Unknown cluster {cluster!r}. Set OPENSHIFT_CLUSTERS (JSON name->url) "
        f"or OPENSHIFT_API_URL_TEMPLATE, or pass the full API URL."
    )


def default_tls_verify() -> bool | str:
    """Return the httpx ``verify`` value from env (CA bundle path, or skip-verify flag)."""
    if os.getenv("OPENSHIFT_INSECURE_SKIP_TLS_VERIFY", "").lower() in {"1", "true", "yes"}:
        logger.warning("TLS verification disabled for OpenShift API calls")
        return False
    if ca := os.getenv("OPENSHIFT_CA_BUNDLE", "").strip():
        return ca
    return True


# --------------------------------------------------------------------------- #
# ConfigMap reference extraction
# --------------------------------------------------------------------------- #
@dataclass
class ConfigMapRef:
    """A ConfigMap referenced by a pod template."""

    name: str
    optional: bool = False
    usages: list[str] = field(default_factory=list)


def _pod_spec_of(workload: dict[str, Any]) -> dict[str, Any]:
    """Extract the pod spec from a Deployment/StatefulSet/DeploymentConfig object."""
    return (workload.get("spec") or {}).get("template", {}).get("spec", {}) or {}


def extract_configmap_refs(pod_spec: dict[str, Any]) -> list[ConfigMapRef]:
    """Find every ConfigMap a pod template consumes.

    Covers volumes, projected volumes, ``envFrom.configMapRef`` and
    ``env[].valueFrom.configMapKeyRef`` across containers, initContainers and
    ephemeralContainers.

    Args:
        pod_spec: The ``spec.template.spec`` block of the workload.

    Returns:
        Deduplicated refs, in first-seen order.
    """
    refs: dict[str, ConfigMapRef] = {}

    def add(name: str | None, usage: str, optional: bool) -> None:
        if not name:
            return
        ref = refs.setdefault(name, ConfigMapRef(name=name, optional=optional))
        # A ConfigMap is only truly optional if every reference to it is optional.
        ref.optional = ref.optional and optional
        if usage not in ref.usages:
            ref.usages.append(usage)

    # --- volumes -----------------------------------------------------------
    for volume in pod_spec.get("volumes") or []:
        vol_name = volume.get("name", "?")
        if cm := volume.get("configMap"):
            add(cm.get("name"), f"volume/{vol_name}", bool(cm.get("optional")))
        for source in (volume.get("projected") or {}).get("sources") or []:
            if cm := source.get("configMap"):
                add(cm.get("name"), f"projected-volume/{vol_name}", bool(cm.get("optional")))

    # --- containers --------------------------------------------------------
    container_groups = (
        ("container", pod_spec.get("containers")),
        ("initContainer", pod_spec.get("initContainers")),
        ("ephemeralContainer", pod_spec.get("ephemeralContainers")),
    )
    for label, containers in container_groups:
        for container in containers or []:
            cname = container.get("name", "?")

            for entry in container.get("envFrom") or []:
                if cm := entry.get("configMapRef"):
                    add(cm.get("name"), f"{label}/{cname} envFrom", bool(cm.get("optional")))

            for env in container.get("env") or []:
                cm = (env.get("valueFrom") or {}).get("configMapKeyRef")
                if cm:
                    usage = f"{label}/{cname} env {env.get('name')}->{cm.get('key')}"
                    add(cm.get("name"), usage, bool(cm.get("optional")))

    return list(refs.values())


# --------------------------------------------------------------------------- #
# Client
# --------------------------------------------------------------------------- #
@dataclass
class _CachedToken:
    value: str
    expires_at: float

    @property
    def valid(self) -> bool:
        return time.time() < self.expires_at


class OpenShiftClient:
    """Minimal async OpenShift API client using FID/username/password auth."""

    def __init__(
        self,
        api_url: str,
        username: str,
        password: str,
        *,
        verify: bool | str | None = None,
        timeout: float = 30.0,
    ):
        """Initialize the client.

        Args:
            api_url: API server URL, e.g. https://api.cluster.corp.net:6443
            username: FID / username.
            password: Password for the FID.
            verify: httpx TLS verify value; defaults to env-derived setting.
            timeout: Per-request timeout in seconds.
        """
        self._api_url = api_url.rstrip("/")
        self._username = username
        self._password = password
        self._verify = default_tls_verify() if verify is None else verify
        self._timeout = timeout
        self._token: _CachedToken | None = None
        self._http: httpx.AsyncClient | None = None

    async def __aenter__(self) -> "OpenShiftClient":
        self._http = httpx.AsyncClient(verify=self._verify, timeout=self._timeout)
        return self

    async def __aexit__(self, *_exc: object) -> None:
        if self._http:
            await self._http.aclose()
            self._http = None

    @property
    def _client(self) -> httpx.AsyncClient:
        if self._http is None:
            raise RuntimeError("Use OpenShiftClient as an async context manager")
        return self._http

    # ----------------------------- auth ---------------------------------- #
    async def _authorization_endpoint(self) -> str:
        """Discover the OAuth authorize endpoint from the API server metadata."""
        url = f"{self._api_url}/.well-known/oauth-authorization-server"
        response = await self._client.get(url)
        if response.status_code != 200:
            raise OpenShiftError(
                f"Could not read OAuth metadata from {url} (HTTP {response.status_code})"
            )
        endpoint = response.json().get("authorization_endpoint")
        if not endpoint:
            raise OpenShiftError(f"No authorization_endpoint in OAuth metadata from {url}")
        return endpoint

    async def token(self) -> str:
        """Return a bearer token, logging in via the OAuth challenge flow if needed.

        Returns:
            The access token (e.g. ``sha256~...``).

        Raises:
            AuthenticationError: If the credentials are rejected.
        """
        if self._token and self._token.valid:
            return self._token.value

        authorize_url = await self._authorization_endpoint()
        basic = base64.b64encode(f"{self._username}:{self._password}".encode()).decode()

        response = await self._client.get(
            authorize_url,
            params={"client_id": "openshift-challenging-client", "response_type": "token"},
            headers={"Authorization": f"Basic {basic}", "X-CSRF-Token": "1"},
            follow_redirects=False,
        )

        match response.status_code:
            case 302 | 303:
                pass
            case 401:
                raise AuthenticationError(
                    f"OpenShift rejected credentials for {self._username!r} (401). "
                    "Check the FID, password, and that it is not locked or expired."
                )
            case status:
                raise AuthenticationError(f"Unexpected login response (HTTP {status})")

        location = response.headers.get("location", "")
        params = parse_qs(urlparse(location).fragment)
        token = (params.get("access_token") or [None])[0]
        if not token:
            error = (params.get("error_description") or params.get("error") or ["no token"])[0]
            raise AuthenticationError(f"Login failed: {error}")

        expires_in = int((params.get("expires_in") or ["86400"])[0])
        self._token = _CachedToken(
            value=token,
            expires_at=time.time() + max(expires_in - _TOKEN_SKEW_SECONDS, 60),
        )
        logger.info("openshift_login_ok user=%s api=%s", self._username, self._api_url)
        return token

    # ----------------------------- requests ------------------------------ #
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=10),
        retry=retry_if_exception_type((httpx.TransportError, RetryableApiError)),
        before_sleep=before_sleep_log(logger, logging.WARNING),
        reraise=True,
    )
    async def _get(self, path: str) -> dict[str, Any] | None:
        """GET an API path. Returns None on 404.

        Args:
            path: API path beginning with '/', e.g. '/api/v1/namespaces/x/configmaps/y'.

        Returns:
            Decoded JSON object, or None if the resource does not exist.
        """
        token = await self.token()
        response = await self._client.get(
            f"{self._api_url}{path}",
            headers={"Authorization": f"Bearer {token}", "Accept": "application/json"},
        )

        match response.status_code:
            case 200:
                return response.json()
            case 404:
                return None
            case 401 | 403:
                self._token = None  # force re-login on next attempt
                raise ApiError(response.status_code, f"Not authorized for {path}")
            case status if status >= 500 or status == 429:
                raise RetryableApiError(status, response.text[:300])
            case status:
                raise ApiError(status, response.text[:300])

    # ----------------------------- resources ----------------------------- #
    @staticmethod
    def _workload_path(kind: str, namespace: str, name: str) -> tuple[str, str]:
        """Return (api_path, canonical_kind) for a workload kind."""
        match kind.lower():
            case "deployment" | "deploy":
                return f"/apis/apps/v1/namespaces/{namespace}/deployments/{name}", "Deployment"
            case "statefulset" | "sts":
                return f"/apis/apps/v1/namespaces/{namespace}/statefulsets/{name}", "StatefulSet"
            case "deploymentconfig" | "dc":
                return (
                    f"/apis/apps.openshift.io/v1/namespaces/{namespace}/deploymentconfigs/{name}",
                    "DeploymentConfig",
                )
            case other:
                raise ValueError(f"Unsupported workload kind: {other!r}")

    async def get_workload(
        self, kind: WorkloadKind, namespace: str, name: str
    ) -> tuple[str, dict[str, Any]]:
        """Fetch a Deployment, StatefulSet or DeploymentConfig.

        Args:
            kind: Explicit kind, or "auto" to probe each type in turn.
            namespace: Project / namespace name.
            name: Workload name.

        Returns:
            Tuple of (canonical kind, workload object).

        Raises:
            WorkloadNotFoundError: If nothing matches.
        """
        candidates = (
            ["deployment", "statefulset", "deploymentconfig"] if kind == "auto" else [kind]
        )
        for candidate in candidates:
            path, canonical = self._workload_path(candidate, namespace, name)
            if obj := await self._get(path):
                return canonical, obj

        raise WorkloadNotFoundError(
            f"No {'/'.join(candidates)} named {name!r} in namespace {namespace!r}"
        )

    async def get_configmap(self, namespace: str, name: str) -> dict[str, Any] | None:
        """Fetch a single ConfigMap, or None if it does not exist."""
        return await self._get(f"/api/v1/namespaces/{namespace}/configmaps/{name}")

    async def list_configmaps(self, namespace: str) -> list[dict[str, Any]]:
        """List every ConfigMap in a namespace."""
        result = await self._get(f"/api/v1/namespaces/{namespace}/configmaps")
        return (result or {}).get("items", [])


# --------------------------------------------------------------------------- #
# Orchestration
# --------------------------------------------------------------------------- #
async def get_configmaps_for_workload(
    *,
    cluster: str,
    namespace: str,
    name: str,
    username: str,
    password: str,
    kind: WorkloadKind = "auto",
    include_data: bool = True,
    verify: bool | str | None = None,
) -> dict[str, Any]:
    """Resolve and fetch every ConfigMap used by a workload.

    Args:
        cluster: Cluster name (resolved via env config) or full API URL.
        namespace: Project / namespace.
        name: Deployment / StatefulSet / DeploymentConfig name.
        username: FID / username.
        password: Password.
        kind: Workload kind, or "auto" to detect.
        include_data: Include ConfigMap ``data`` in the result.
        verify: TLS verify override.

    Returns:
        A JSON-serializable summary of the workload and its ConfigMaps.
    """
    api_url = resolve_api_url(cluster)

    async with OpenShiftClient(api_url, username, password, verify=verify) as client:
        canonical_kind, workload = await client.get_workload(kind, namespace, name)
        refs = extract_configmap_refs(_pod_spec_of(workload))

        fetched = await asyncio.gather(
            *(client.get_configmap(namespace, ref.name) for ref in refs)
        )

    config_maps: list[dict[str, Any]] = []
    missing: list[str] = []

    for ref, obj in zip(refs, fetched):
        entry: dict[str, Any] = {
            "name": ref.name,
            "found": obj is not None,
            "optional": ref.optional,
            "usedBy": ref.usages,
        }
        if obj is None:
            missing.append(ref.name)
        else:
            metadata = obj.get("metadata", {})
            entry["resourceVersion"] = metadata.get("resourceVersion")
            entry["creationTimestamp"] = metadata.get("creationTimestamp")
            entry["keys"] = sorted((obj.get("data") or {}).keys())
            entry["binaryDataKeys"] = sorted((obj.get("binaryData") or {}).keys())
            if include_data:
                entry["data"] = obj.get("data") or {}
        config_maps.append(entry)

    return {
        "cluster": cluster,
        "apiUrl": api_url,
        "namespace": namespace,
        "workload": {"kind": canonical_kind, "name": name},
        "configMapCount": len(config_maps),
        "configMaps": config_maps,
        "missing": missing,
    }


# --------------------------------------------------------------------------- #
# CLI
# --------------------------------------------------------------------------- #
def _main() -> None:
    parser = argparse.ArgumentParser(description="Pull ConfigMaps for an OpenShift workload")
    parser.add_argument("--cluster", required=True, help="Cluster name or API URL")
    parser.add_argument("--namespace", required=True)
    parser.add_argument("--name", required=True, help="Deployment / StatefulSet name")
    parser.add_argument(
        "--kind",
        default="auto",
        choices=["auto", "deployment", "statefulset", "deploymentconfig"],
    )
    parser.add_argument("--username", default=os.getenv("OPENSHIFT_USERNAME"))
    parser.add_argument("--password", default=os.getenv("OPENSHIFT_PASSWORD"))
    parser.add_argument("--no-data", action="store_true", help="Omit ConfigMap data")
    parser.add_argument("--log-level", default="WARNING")
    args = parser.parse_args()

    logging.basicConfig(level=args.log_level.upper())

    if not args.username or not args.password:
        parser.error("Provide --username/--password or set OPENSHIFT_USERNAME/OPENSHIFT_PASSWORD")

    result = asyncio.run(
        get_configmaps_for_workload(
            cluster=args.cluster,
            namespace=args.namespace,
            name=args.name,
            username=args.username,
            password=args.password,
            kind=args.kind,
            include_data=not args.no_data,
        )
    )
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    _main()
