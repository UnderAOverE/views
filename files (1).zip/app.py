"""FastAPI service: POST a cluster/namespace/workload, get back its ConfigMaps."""

from __future__ import annotations

import logging
import os
from typing import Any, Literal

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field, SecretStr

from openshift_configmaps import (
    ApiError,
    AuthenticationError,
    ClusterNotConfiguredError,
    WorkloadNotFoundError,
    get_configmaps_for_workload,
)

logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"))
logger = logging.getLogger(__name__)

app = FastAPI(title="OpenShift ConfigMap Lookup", version="1.0.0")


class ConfigMapRequest(BaseModel):
    """Request body for /configmaps."""

    cluster: str = Field(..., description="Cluster name (see OPENSHIFT_CLUSTERS) or API URL")
    namespace: str = Field(..., description="Project / namespace")
    name: str = Field(..., description="Deployment or StatefulSet name")
    kind: Literal["auto", "deployment", "statefulset", "deploymentconfig"] = "auto"
    username: str | None = Field(None, description="FID; falls back to OPENSHIFT_USERNAME")
    password: SecretStr | None = Field(None, description="Falls back to OPENSHIFT_PASSWORD")
    include_data: bool = Field(True, description="Include ConfigMap data values")

    model_config = {
        "json_schema_extra": {
            "example": {
                "cluster": "ocp-prod-east",
                "namespace": "payments",
                "name": "payments-api",
                "kind": "auto",
                "username": "fid-svc-reader",
                "password": "••••••••",
            }
        }
    }


def _credentials(body: ConfigMapRequest) -> tuple[str, str]:
    """Resolve credentials from the body, falling back to environment defaults."""
    username = body.username or os.getenv("OPENSHIFT_USERNAME")
    password = (
        body.password.get_secret_value() if body.password else os.getenv("OPENSHIFT_PASSWORD")
    )
    if not username or not password:
        raise HTTPException(
            status_code=400,
            detail="Provide username/password in the body or set "
            "OPENSHIFT_USERNAME / OPENSHIFT_PASSWORD.",
        )
    return username, password


@app.post("/configmaps", summary="Get ConfigMaps used by a workload")
async def configmaps(body: ConfigMapRequest) -> dict[str, Any]:
    """Return every ConfigMap referenced by the target Deployment/StatefulSet."""
    username, password = _credentials(body)

    try:
        return await get_configmaps_for_workload(
            cluster=body.cluster,
            namespace=body.namespace,
            name=body.name,
            username=username,
            password=password,
            kind=body.kind,
            include_data=body.include_data,
        )
    except ClusterNotConfiguredError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except AuthenticationError as exc:
        raise HTTPException(status_code=401, detail=str(exc)) from exc
    except WorkloadNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ApiError as exc:
        status = 403 if exc.status_code in (401, 403) else 502
        raise HTTPException(status_code=status, detail=str(exc)) from exc
    except Exception as exc:  # noqa: BLE001 - surface a clean error to the caller
        logger.exception("configmap_lookup_failed")
        raise HTTPException(status_code=500, detail=f"Lookup failed: {exc}") from exc


@app.get("/health", summary="Liveness probe")
async def health() -> dict[str, str]:
    """Simple health endpoint."""
    return {"status": "ok"}
