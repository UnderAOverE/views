import asyncio
import json
from datetime import datetime, timezone
from pathlib import Path

from src.models.appdynamics import FetchError


class ErrorReporter:
    """
    Collects FetchError instances during a run, then writes:
      - <dir>/appdynamics_errors.json  (overwrites each run)
      - <dir>/appdynamics_errors.html  (overwrites each run)
    """

    def __init__(self, report_dir: str = "logs/appdynamics"):
        self._dir = Path(report_dir)
        self._dir.mkdir(parents=True, exist_ok=True)
        self._errors: list[FetchError] = []
        self._lock = asyncio.Lock()

    async def record(self, error: FetchError) -> None:
        async with self._lock:
            self._errors.append(error)

    def has_errors(self) -> bool:
        return bool(self._errors)

    async def flush(self) -> None:
        """Write both report files. Safe to call even when there are no errors."""
        async with self._lock:
            errors_snapshot = list(self._errors)

        await asyncio.gather(
            asyncio.to_thread(self._write_json, errors_snapshot),
            asyncio.to_thread(self._write_html, errors_snapshot),
        )

    def _write_json(self, errors: list[FetchError]) -> None:
        path = self._dir / "appdynamics_errors.json"
        payload = {
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "total_errors": len(errors),
            "errors": [e.to_dict() for e in errors],
        }
        path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    def _write_html(self, errors: list[FetchError]) -> None:
        path = self._dir / "appdynamics_errors.html"

        rows = ""
        for e in errors:
            rows += f"""
            <tr>
                <td>{e.occurred_at.isoformat()}</td>
                <td>{e.controller_name}</td>
                <td>{e.user}</td>
                <td>{e.application}</td>
                <td><code>{e.metric_path}</code></td>
                <td><span class="badge {e.error_type.lower()}">{e.error_type}</span></td>
                <td>{e.detail}</td>
            </tr>"""

        status_color = "#e74c3c" if errors else "#2ecc71"
        status_text = f"{len(errors)} error(s) found" if errors else "All metrics fetched successfully"

        html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>AppDynamics Fetch Error Report</title>
    <style>
        * {{ box-sizing: border-box; margin: 0; padding: 0; }}
        body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; background: #f5f6fa; color: #2d3436; }}
        header {{ background: #2d3436; color: #fff; padding: 24px 32px; }}
        header h1 {{ font-size: 1.4rem; font-weight: 600; }}
        header p {{ font-size: 0.85rem; opacity: 0.6; margin-top: 4px; }}
        .summary {{ margin: 24px 32px; padding: 16px 20px; border-radius: 8px;
                    background: {status_color}18; border-left: 4px solid {status_color}; }}
        .summary strong {{ color: {status_color}; font-size: 1rem; }}
        .container {{ margin: 0 32px 32px; }}
        table {{ width: 100%; border-collapse: collapse; background: #fff;
                 border-radius: 8px; overflow: hidden; box-shadow: 0 1px 4px rgba(0,0,0,.08); }}
        th {{ background: #2d3436; color: #fff; padding: 12px 16px; font-size: 0.8rem;
              text-align: left; text-transform: uppercase; letter-spacing: .05em; }}
        td {{ padding: 11px 16px; font-size: 0.875rem; border-bottom: 1px solid #f0f0f0; vertical-align: top; }}
        tr:last-child td {{ border-bottom: none; }}
        tr:hover td {{ background: #f9f9f9; }}
        code {{ background: #f0f0f0; padding: 2px 6px; border-radius: 4px; font-size: 0.8rem; word-break: break-all; }}
        .badge {{ padding: 2px 8px; border-radius: 12px; font-size: 0.75rem; font-weight: 600; }}
        .badge.http_error {{ background: #ffeaa7; color: #e17055; }}
        .badge.parse_error {{ background: #dfe6e9; color: #636e72; }}
        .badge.cred_missing {{ background: #fd79a8; color: #6c2b3e; }}
        .badge.token_error {{ background: #a29bfe; color: #2d3436; }}
        .badge.disabled {{ background: #b2bec3; color: #2d3436; }}
        .no-errors {{ text-align: center; padding: 40px; color: #b2bec3; font-size: 0.9rem; }}
    </style>
</head>
<body>
    <header>
        <h1>AppDynamics Fetch Error Report</h1>
        <p>Generated: {datetime.now(timezone.utc).isoformat()}</p>
    </header>
    <div class="summary"><strong>{status_text}</strong></div>
    <div class="container">
        <table>
            <thead>
                <tr>
                    <th>Timestamp</th>
                    <th>Controller</th>
                    <th>User</th>
                    <th>Application</th>
                    <th>Metric Path</th>
                    <th>Error Type</th>
                    <th>Detail</th>
                </tr>
            </thead>
            <tbody>
                {"".join(rows) if errors else '<tr><td colspan="7" class="no-errors">No errors recorded in this run.</td></tr>'}
            </tbody>
        </table>
    </div>
</body>
</html>"""
        path.write_text(html, encoding="utf-8")