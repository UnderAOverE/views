"""
Smart parser that extracts (category, tier, node, metric_name) from an
AppDynamics resolved metric path.

Each metric category has its own path structure:

  Application Infrastructure Performance|<tier>|Individual Nodes|<node>|...|<metric>
  Backends|<backend_name>|<metric>
  Business Transaction Performance|<tier>|<bt_name>|...|<metric>
  Service Endpoints|<tier>|<endpoint_name>|...|<metric>
  Errors|<tier>|...|<metric>
  Overall Application Performance|...|<metric>
  Database Monitoring|<db_name>|...|<metric>

Returns ("", "", "", metric_name) as a fallback for unrecognised shapes.
"""

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class ParsedMetricPath:
    category: str
    tier: str
    node: str
    metric_name: str


def parse_metric_path(metric_path: str) -> ParsedMetricPath:
    """
    Extracts structured fields from a resolved AppDynamics metric path.
    """
    parts = [p.strip() for p in metric_path.split("|")]
    if not parts:
        return ParsedMetricPath("", "", "", "")

    category = parts[0]
    metric_name = parts[-1] if len(parts) > 1 else ""

    # ── Application Infrastructure Performance ────────────────────────
    # <category>|<tier>|Individual Nodes|<node>|...|<metric>
    if category == "Application Infrastructure Performance":
        tier = parts[1] if len(parts) > 1 else ""
        node = ""
        try:
            idx = next(i for i, p in enumerate(parts) if p == "Individual Nodes")
            if idx + 1 < len(parts):
                node = parts[idx + 1]
        except StopIteration:
            pass
        return ParsedMetricPath(category, tier, node, metric_name)

    # ── Backends ──────────────────────────────────────────────────────
    # <category>|<backend_name>|...|<metric>
    if category == "Backends":
        tier = parts[1] if len(parts) > 1 else ""
        return ParsedMetricPath(category, tier, "", metric_name)

    # ── Business Transaction Performance ──────────────────────────────
    # <category>|Business Transactions|<tier>|<bt_name>|...|<metric>
    # OR  <category>|<tier>|<bt_name>|...|<metric>
    if category == "Business Transaction Performance":
        tier = ""
        if len(parts) > 1:
            # Skip "Business Transactions" if present as second segment
            offset = 2 if parts[1] == "Business Transactions" else 1
            tier = parts[offset] if len(parts) > offset else ""
        return ParsedMetricPath(category, tier, "", metric_name)

    # ── Service Endpoints ─────────────────────────────────────────────
    # <category>|<tier>|<endpoint_name>|...|<metric>
    if category == "Service Endpoints":
        tier = parts[1] if len(parts) > 1 else ""
        return ParsedMetricPath(category, tier, "", metric_name)

    # ── Errors ────────────────────────────────────────────────────────
    # <category>|<tier>|...|<metric>
    if category == "Errors":
        tier = parts[1] if len(parts) > 1 else ""
        return ParsedMetricPath(category, tier, "", metric_name)

    # ── Overall Application Performance ───────────────────────────────
    # <category>|...|<metric>   (app-level, no tier or node)
    if category == "Overall Application Performance":
        return ParsedMetricPath(category, "", "", metric_name)

    # ── Database Monitoring ───────────────────────────────────────────
    # <category>|<db_name>|...|<metric>
    if category.startswith("Database Monitoring"):
        tier = parts[1] if len(parts) > 1 else ""
        return ParsedMetricPath(category, tier, "", metric_name)

    # ── Fallback for unknown categories ───────────────────────────────
    tier = parts[1] if len(parts) > 1 else ""
    return ParsedMetricPath(category, tier, "", metric_name)