import asyncio
import logging
from datetime import datetime, timezone
from urllib.parse import urlencode

from src.config.appdynamics_settings import AppDynamicsSettings, AppConfig, MetricQuery
from src.models.appdynamics import (
    MetricDataPoint, MetricMetadata, PlatformMetricDocument, FetchError,
    ControllerDocument,
)
from src.repository.appdynamics_credentials_repository import AppDynamicsCredentialsRepository
from src.repository.platform_metrics_repository import PlatformMetricsRepository
from src.utils.error_reporter import ErrorReporter
from src.utils.metric_path_parser import parse_metric_path

logger = logging.getLogger(__name__)


def _build_metric_url(base_url: str, app_name: str, query: MetricQuery) -> str:
    params = {
        "metric-path": query.metric_path,
        "time-range-type": query.time_range_type,
        "duration-in-mins": str(query.duration_in_mins),
        "rollup": "true" if query.rollup else "false",
        "output": "json",
    }
    return (
        f"{base_url.rstrip('/')}/controller/rest/applications/"
        f"{app_name}/metric-data?{urlencode(params)}"
    )


def _ms_to_datetime(ms: int | None) -> datetime | None:
    """Convert epoch milliseconds to a UTC datetime, or None."""
    if not ms:
        return None
    return datetime.fromtimestamp(ms / 1000.0, tz=timezone.utc)


def _parse_response_to_documents(
    raw: dict | list,
    metadata: MetricMetadata,
    application: str,
    query: MetricQuery,
) -> list[PlatformMetricDocument]:
    if not isinstance(raw, list):
        return []

    filter_set = {m.strip() for m in query.filter_metrics} if query.filter_metrics else set()
    documents: list[PlatformMetricDocument] = []

    for item in raw:
        try:
            data_point = MetricDataPoint.model_validate(item)
        except Exception:
            continue

        parsed = parse_metric_path(data_point.metric_path)

        if filter_set and parsed.metric_name not in filter_set:
            continue

        for mv in data_point.metric_values:
            documents.append(
                PlatformMetricDocument(
                    metadata=metadata,
                    application=application,
                    category=parsed.category,
                    tier=parsed.tier,
                    node=parsed.node,
                    metric_name=parsed.metric_name,
                    metric_value=mv.value,
                    query_time=_ms_to_datetime(mv.start_time_ms),
                )
            )

    return documents


class AppDynamicsService:
    """
    Orchestrates fetching AppDynamics metrics and persisting them to MongoDB.

    Token management is handled externally — this service reads the current
    bearer_token from the controller document and uses it as-is.  If the token
    is expired it logs an error and skips the request.

    Inject your existing clients:
      - httpx_client:    your HTTPXClient instance
      - semaphore:       asyncio.Semaphore (controls concurrency across all tasks)
      - creds_repo:      AppDynamicsCredentialsRepository
      - metrics_repo:    PlatformMetricsRepository
      - settings:        AppDynamicsSettings
      - error_reporter:  ErrorReporter (collects errors; call .flush() after run)
    """

    def __init__(
        self,
        httpx_client,
        semaphore: asyncio.Semaphore,
        creds_repo: AppDynamicsCredentialsRepository,
        metrics_repo: PlatformMetricsRepository,
        settings: AppDynamicsSettings,
        error_reporter: ErrorReporter,
    ):
        self._http = httpx_client
        self._sem = semaphore
        self._creds_repo = creds_repo
        self._metrics_repo = metrics_repo
        self._settings = settings
        self._reporter = error_reporter

    # ── Public entry point ────────────────────────────────────────────────────

    async def run(self) -> dict[str, int]:
        """
        Fetch all configured metrics for all controllers and apps.
        Returns a summary: { "fetched": N, "stored": N, "errors": N }
        """
        tasks = []

        for ctrl_cfg in self._settings.controllers:
            controller_doc = await self._creds_repo.get_by_name(ctrl_cfg.name)

            if not controller_doc:
                logger.error("Controller '%s' not found in MongoDB — skipping.", ctrl_cfg.name)
                for app in ctrl_cfg.apps:
                    for query in app.metric_queries:
                        await self._reporter.record(FetchError(
                            controller_name=ctrl_cfg.name,
                            endpoint="unknown",
                            application=app.app_name,
                            user=app.user,
                            metric_path=query.metric_path,
                            error_type="CRED_MISSING",
                            detail=f"No MongoDB document for controller_name='{ctrl_cfg.name}'",
                        ))
                continue

            if not controller_doc.enable:
                logger.info("Controller '%s' is disabled — skipping.", ctrl_cfg.name)
                continue

            for app in ctrl_cfg.apps:
                for query in app.metric_queries:
                    tasks.append(
                        self._fetch_and_store(controller_doc, ctrl_cfg.name, app, query)
                    )

        results = await asyncio.gather(*tasks, return_exceptions=True)

        stored = sum(r for r in results if isinstance(r, int))
        await self._reporter.flush()

        return {
            "fetched": len(tasks),
            "stored": stored,
            "errors": len(self._reporter._errors),
        }

    # ── Internal helpers ──────────────────────────────────────────────────────

    async def _fetch_and_store(
        self,
        controller_doc: ControllerDocument,
        controller_name: str,
        app: AppConfig,
        query: MetricQuery,
    ) -> int:
        # ── Read bearer token (no refresh — external process handles that) ───
        user = controller_doc.get_user(app.user)
        if not user:
            msg = f"User '{app.user}' not in controller '{controller_name}' login_details"
            logger.error(msg)
            await self._reporter.record(FetchError(
                controller_name=controller_name,
                endpoint=controller_doc.url,
                application=app.app_name,
                user=app.user,
                metric_path=query.metric_path,
                error_type="CRED_MISSING",
                detail=msg,
            ))
            return 0

        if user.is_token_expired():
            msg = (
                f"Bearer token expired for {controller_name}/{app.user} "
                f"(expiry: {user.bearer_token_expiration}). "
                f"Waiting for external refresh process."
            )
            logger.warning(msg)
            await self._reporter.record(FetchError(
                controller_name=controller_name,
                endpoint=controller_doc.url,
                application=app.app_name,
                user=app.user,
                metric_path=query.metric_path,
                error_type="TOKEN_EXPIRED",
                detail=msg,
            ))
            return 0

        url = _build_metric_url(controller_doc.url, app.app_name, query)
        headers = {"Authorization": f"Bearer {user.bearer_token}", "Accept": "application/json"}

        # ── Fetch ─────────────────────────────────────────────────────────────
        async with self._sem:
            await asyncio.sleep(0.1)
            raw = await self._http.call_async(url=url, json_data=None, method="GET", headers=headers)

        if isinstance(raw, str):
            logger.warning("HTTP error %s / %s: %s", controller_name, app.app_name, raw)
            await self._reporter.record(FetchError(
                controller_name=controller_name,
                endpoint=controller_doc.url,
                application=app.app_name,
                user=app.user,
                metric_path=query.metric_path,
                error_type="HTTP_ERROR",
                detail=raw,
            ))
            return 0

        # ── Parse ─────────────────────────────────────────────────────────────
        metadata = MetricMetadata(
            controller_name=controller_name,
            endpoint=controller_doc.url,
            user=app.user,
            time_range_type=query.time_range_type,
            duration_in_mins=query.duration_in_mins,
        )

        try:
            documents = _parse_response_to_documents(
                raw=raw,
                metadata=metadata,
                application=app.app_name,
                query=query,
            )
        except Exception as exc:
            logger.exception("Parse error %s / %s", controller_name, app.app_name)
            await self._reporter.record(FetchError(
                controller_name=controller_name,
                endpoint=controller_doc.url,
                application=app.app_name,
                user=app.user,
                metric_path=query.metric_path,
                error_type="PARSE_ERROR",
                detail=str(exc),
            ))
            return 0

        if not documents:
            logger.debug("No documents after filter for %s / %s", app.app_name, query.metric_path)
            return 0

        stored = await self._metrics_repo.insert_many(documents)
        logger.debug("Stored %d docs — %s / %s", stored, app.app_name, query.metric_path)
        return stored


# ── Factory ───────────────────────────────────────────────────────────────────

def create_appdynamics_service(
    httpx_client,
    creds_repo: AppDynamicsCredentialsRepository,
    metrics_repo: PlatformMetricsRepository,
    settings: AppDynamicsSettings,
    error_reporter: ErrorReporter,
) -> AppDynamicsService:
    """
    Convenience factory — creates the semaphore internally.
    """
    semaphore = asyncio.Semaphore(settings.concurrency_limit)
    return AppDynamicsService(
        httpx_client=httpx_client,
        semaphore=semaphore,
        creds_repo=creds_repo,
        metrics_repo=metrics_repo,
        settings=settings,
        error_reporter=error_reporter,
    )