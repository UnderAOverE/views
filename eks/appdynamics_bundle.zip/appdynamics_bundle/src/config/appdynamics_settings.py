from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings


class MetricQuery(BaseModel):
    metric_path: str
    time_range_type: str = "BEFORE_NOW"
    duration_in_mins: int = 10
    rollup: bool = False
    filter_metrics: list[str] = Field(
        default_factory=list,
        description="Leaf metric names to keep. Empty = keep all."
    )


class AppConfig(BaseModel):
    app_name: str        # e.g. "1223287_MBOL_PRD"
    user: str            # must match a key in login_details e.g. "aichatcore"
    metric_queries: list[MetricQuery]


class ControllerConfig(BaseModel):
    name: str            # must match controller.name in MongoDB e.g. "p14"
    apps: list[AppConfig]


class AppDynamicsSettings(BaseSettings):
    controllers: list[ControllerConfig] = Field(default_factory=list)
    concurrency_limit: int = 5
    error_report_dir: str = "logs/appdynamics"

    model_config = {
        "env_prefix": "APPDYNAMICS_",
        "env_nested_delimiter": "__",
        "env_file": "appdynamics.env",
        "env_file_encoding": "utf-8",
    }