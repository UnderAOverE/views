from datetime import datetime, timedelta, timezone
from typing import Any
from pydantic import BaseModel, Field


# ── AppDynamics REST API response models ──────────────────────────────────────

class MetricValue(BaseModel):
    start_time_ms: int = Field(alias="startTimeInMillis", default=0)
    value: float | int | None = None

    model_config = {"populate_by_name": True}


class MetricDataPoint(BaseModel):
    metric_name: str = Field(alias="metricName", default="")
    metric_path: str = Field(alias="metricPath", default="")
    metric_id: int | None = Field(alias="metricId", default=None)
    frequency: str | None = None
    metric_values: list[MetricValue] = Field(alias="metricValues", default_factory=list)

    model_config = {"populate_by_name": True}


# ── MongoDB stored document ───────────────────────────────────────────────────

class MetricMetadata(BaseModel):
    """Non-metric context: who fetched, from where, and with what query params."""
    controller_name: str
    endpoint: str
    user: str
    time_range_type: str
    duration_in_mins: int


class PlatformMetricDocument(BaseModel):
    metadata: MetricMetadata
    application: str
    category: str               # e.g. "Backends", "Application Infrastructure Performance", etc.
    tier: str                   # parsed from metric path; "" when N/A
    node: str                   # parsed from metric path; "" when N/A
    metric_name: str            # leaf metric name, e.g. "AverageReads"
    metric_value: float | int | None
    query_time: datetime | None  # converted from startTimeInMillis
    log_datetime: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    def to_mongo(self) -> dict[str, Any]:
        return self.model_dump()


# ── Credential models (matching MongoDB schema) ───────────────────────────────

class UserLoginDetails(BaseModel):
    """
    Maps to one entry inside controller.oauth2.login_details.
    e.g. login_details.aichatcore -> UserLoginDetails
    """
    secret_key: str
    secret_token: str
    bearer_token: str | None = None
    bearer_token_expiration: datetime | None = None

    def is_token_expired(self, buffer_secs: int = 60) -> bool:
        """Returns True if bearer token is missing or expiring within buffer_secs."""
        if not self.bearer_token or not self.bearer_token_expiration:
            return True
        now = datetime.now(timezone.utc)
        exp = self.bearer_token_expiration
        if exp.tzinfo is None:
            exp = exp.replace(tzinfo=timezone.utc)
        return now >= (exp - timedelta(seconds=buffer_secs))


class OAuth2Config(BaseModel):
    method: str = "POST"
    headers: dict[str, str] = Field(default_factory=dict)
    path: str = "/controller/api/oauth/access_token"
    login_details: dict[str, UserLoginDetails]  # keyed by user name


class ControllerDocument(BaseModel):
    """
    Full controller document as stored in MongoDB.
    Mirrors the collection schema.
    """
    name: str
    environment: str
    enable: bool = True
    url: str
    account: str
    oauth2: OAuth2Config
    method: str = "GET"
    timeout: int = 60
    ca_certs: str | None = None   # populated from https.ca_certs when enabled

    def get_user(self, user_name: str) -> UserLoginDetails | None:
        return self.oauth2.login_details.get(user_name)


# ── Error tracking ────────────────────────────────────────────────────────────

class FetchError(BaseModel):
    controller_name: str
    endpoint: str
    application: str
    user: str = ""
    metric_path: str
    error_type: str       # HTTP_ERROR | PARSE_ERROR | CRED_MISSING | TOKEN_EXPIRED | DISABLED
    detail: str
    occurred_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> dict[str, Any]:
        data = self.model_dump()
        data["occurred_at"] = data["occurred_at"].isoformat()
        return data