from motor.motor_asyncio import AsyncIOMotorDatabase

from src.models.appdynamics import PlatformMetricDocument


class PlatformMetricsRepository:
    """Stores resolved AppDynamics metric documents — one document per metric data point."""

    def __init__(self, db: AsyncIOMotorDatabase, collection_name: str = "platform_metrics"):
        self._col = db[collection_name]

    async def insert_many(self, documents: list[PlatformMetricDocument]) -> int:
        if not documents:
            return 0
        result = await self._col.insert_many([doc.to_mongo() for doc in documents])
        return len(result.inserted_ids)

    async def insert_one(self, document: PlatformMetricDocument) -> str:
        result = await self._col.insert_one(document.to_mongo())
        return str(result.inserted_id)


async def get_platform_metrics_repository(
    db: AsyncIOMotorDatabase,
    collection_name: str = "platform_metrics",
) -> PlatformMetricsRepository:
    return PlatformMetricsRepository(db, collection_name)
