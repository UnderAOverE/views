from datetime import datetime
from motor.motor_asyncio import AsyncIOMotorDatabase

from src.models.appdynamics import ControllerDocument, OAuth2Config, UserLoginDetails


class AppDynamicsCredentialsRepository:
    """
    Reads controller documents from MongoDB (read-only).
    Token refresh is handled by an external process.
    Collection name default: 'appdynamics_controller_info'
    """

    def __init__(
        self,
        db: AsyncIOMotorDatabase,
        collection_name: str = "appdynamics_controller_info",
    ):
        self._col = db[collection_name]

    async def get_by_name(self, controller_name: str) -> ControllerDocument | None:
        doc = await self._col.find_one({"controller.name": controller_name})
        if not doc:
            return None
        return self._doc_to_model(doc)

    async def get_all_enabled(self) -> list[ControllerDocument]:
        cursor = self._col.find({"controller.enable": True})
        return [self._doc_to_model(doc) async for doc in cursor]

    # ── Private ───────────────────────────────────────────────────────────────

    def _doc_to_model(self, doc: dict) -> ControllerDocument:
        c = doc["controller"]
        https_cfg = c.get("https", {})

        # Parse login_details into typed models
        raw_login = c.get("oauth2", {}).get("login_details", {})
        login_details: dict[str, UserLoginDetails] = {}
        for user_name, details in raw_login.items():
            expiry = details.get("bearer_token_expiration")
            if isinstance(expiry, dict) and "$date" in expiry:
                expiry = datetime.fromisoformat(expiry["$date"].replace("Z", "+00:00"))
            login_details[user_name] = UserLoginDetails(
                secret_key=details.get("secret_key", ""),
                secret_token=details.get("secret_token", ""),
                bearer_token=details.get("bearer_token"),
                bearer_token_expiration=expiry,
            )

        oauth2 = OAuth2Config(
            method=c["oauth2"].get("method", "POST"),
            headers=c["oauth2"].get("headers", {}),
            path=c["oauth2"].get("path", "/controller/api/oauth/access_token"),
            login_details=login_details,
        )

        return ControllerDocument(
            name=c["name"],
            environment=c.get("environment", ""),
            enable=c.get("enable", True),
            url=c["url"],
            account=c.get("account", ""),
            oauth2=oauth2,
            method=c.get("method", "GET"),
            timeout=c.get("timeout", 60),
            ca_certs=c["https"]["ca_certs"] if https_cfg.get("enable") else None,
        )


async def get_appdynamics_credentials_repository(
    db: AsyncIOMotorDatabase,
    collection_name: str = "appdynamics_controller_info",
) -> AppDynamicsCredentialsRepository:
    return AppDynamicsCredentialsRepository(db, collection_name)