"""
Example: wiring AppDynamicsService into your FastAPI/cron setup.

Assumes you already have:
  - get_mongo_client()        -> motor AsyncIOMotorClient
  - HTTPXClient(...)          -> your async httpx wrapper

Configuration is loaded from 'appdynamics.env' in the project root.
Place the file alongside this script (or set the working directory accordingly).
"""
from src.config.appdynamics_settings import AppDynamicsSettings
from src.repository.appdynamics_credentials_repository import get_appdynamics_credentials_repository
from src.repository.platform_metrics_repository import get_platform_metrics_repository
from src.services.appdynamics_service import create_appdynamics_service
from src.utils.error_reporter import ErrorReporter


async def run_appdynamics_collection(mongo_client, httpx_client) -> dict:
    """
    Call this from your cron scheduler / APScheduler job.
    Returns summary: { "fetched": N, "stored": N, "errors": N }
    """
    settings = AppDynamicsSettings()           # reads from appdynamics.env

    db = mongo_client["your_database_name"]    # <-- replace with your DB name

    creds_repo = await get_appdynamics_credentials_repository(db)
    metrics_repo = await get_platform_metrics_repository(db)
    error_reporter = ErrorReporter(settings.error_report_dir)

    async with httpx_client as client:         # your context manager pattern
        service = create_appdynamics_service(
            httpx_client=client,
            creds_repo=creds_repo,
            metrics_repo=metrics_repo,
            settings=settings,
            error_reporter=error_reporter,
        )
        summary = await service.run()

    return summary