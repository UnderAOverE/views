# AppDynamics Metrics Collector

Fetches metrics from AppDynamics REST API and stores them in MongoDB.

## File Structure

```
src/
├── config/
│   └── appdynamics_settings.py      # Pydantic settings — controllers, metrics, concurrency
├── models/
│   └── appdynamics.py               # All data models (API response, MongoDB doc, errors)
├── repository/
│   ├── appdynamics_credentials_repository.py   # Reads/updates controller OAuth2 docs
│   └── platform_metrics_repository.py          # Writes metric documents to MongoDB
├── services/
│   ├── appdynamics_token_manager.py # OAuth2 token lifecycle (refresh + write-back)
│   └── appdynamics_service.py       # Main orchestrator + factory
└── utils/
    └── error_reporter.py            # Writes appdynamics_errors.json + .html each run
```

## MongoDB Collections

| Collection | Purpose |
|---|---|
| `appdynamics_controller_info` | Controller config + OAuth2 credentials (your existing collection) |
| `platform_metrics` | Output — one document per metric data point |

## Configuration (Environment Variables)

```env
APPDYNAMICS__CONCURRENCY_LIMIT=5
APPDYNAMICS__TOKEN_REFRESH_BUFFER_SECS=300
APPDYNAMICS__ERROR_REPORT_DIR=logs/appdynamics

APPDYNAMICS__CONTROLLERS='[
  {
    "name": "p14",
    "apps": [
      {
        "app_name": "1223287_MBOL_PRD",
        "user": "aichatcore",
        "metric_queries": [
          {
            "metric_path": "Application Infrastructure Performance|334672-MBOL-PLATFORM|Individual Nodes|*|JMX|GemFire_System|Distributed|*",
            "time_range_type": "BEFORE_NOW",
            "duration_in_mins": 10,
            "filter_metrics": ["AverageReads", "MemberCount", "LocatorCount", "UsedHeapSize"]
          }
        ]
      }
    ]
  }
]'
```

## Key Design Notes

- **OAuth2 Bearer tokens** are read from MongoDB, checked for expiry (with configurable buffer),
  refreshed automatically, and written back — so tokens stay fresh across cron runs.
- **`user`** in `AppConfig` must match a key under `controller.oauth2.login_details` in MongoDB
  (e.g. `"aichatcore"`, `"aichat"`, `"aichat_qa"`).
- **`filter_metrics`** lets you use `*` wildcard paths but only persist specific leaf metric names.
- **Error reports** (`appdynamics_errors.json` + `appdynamics_errors.html`) are overwritten each run.
- **Semaphore** is created inside `create_appdynamics_service` from `concurrency_limit` — no need
  to wire it manually.

## Token Refresh Note

Check that your AppDynamics OAuth2 response uses `access_token` (standard). If it uses a different
key, update this line in `appdynamics_token_manager.py`:

```python
bearer_token: str = response.get("access_token") or response.get("bearer_token", "")
```
